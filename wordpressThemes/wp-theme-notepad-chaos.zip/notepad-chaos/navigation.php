<ul id="menu">
  <li id="home"><a href="/">Home</a></li>
  <li id="about"><a href="/?page_id=2">About</a></li>
  <li id="archives"><a href="/?page_id=2">Archives</a></li>
</ul>
