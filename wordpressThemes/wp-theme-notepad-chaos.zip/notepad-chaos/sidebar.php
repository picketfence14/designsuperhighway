<div class="categories-upper"></div>
<div class="categories">
  <ul>
    <?php wp_list_categories('sort_column=name&hierarchical=0&title_li='); ?>
  </ul>
</div>
<div class="categories-btm"></div>
<div class="links">
<ul>
<?php wp_list_bookmarks('categorize=0&title_li='); ?>
</ul>
</div>
<div class="side-meta">
  <ul>
    <?php wp_register(); ?>
    <li>
      <?php wp_loginout(); ?>
    </li>
    <li><a href="http://validator.w3.org/check/referer" title="This page validates as XHTML 1.0 Transitional">Valid <abbr title="eXtensible HyperText Markup Language">XHTML</abbr></a></li>
    <li><a href="http://gmpg.org/xfn/"><abbr title="XHTML Friends Network">XFN</abbr></a></li>
    <li><a href="http://wordpress.org/" title="Powered by WordPress, state-of-the-art semantic personal publishing platform.">WordPress</a></li>
    <?php wp_meta(); ?>
  </ul>
</div>